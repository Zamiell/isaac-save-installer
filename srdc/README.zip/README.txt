Installing Binding of Isaac save files is complicated and prone to error.
Download and run the latest release of the "isaac-save-installer" program, located here:
https://github.com/Zamiell/isaac-save-installer/releases
(Click on "isaac-save-installer.exe" to download it, then run it.)
